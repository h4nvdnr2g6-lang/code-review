"""
OpenEnv typed models for the Code Review environment.
All models are Pydantic v2 with full validation.
"""

from __future__ import annotations

from enum import Enum
from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field, field_validator


# ---------------------------------------------------------------------------
# Enumerations
# ---------------------------------------------------------------------------

class TaskDifficulty(str, Enum):
    EASY = "easy"
    MEDIUM = "medium"
    HARD = "hard"


class ReviewCategory(str, Enum):
    BUG = "bug"
    SECURITY = "security"
    PERFORMANCE = "performance"
    STYLE = "style"
    DOCUMENTATION = "documentation"


class Severity(str, Enum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


# ---------------------------------------------------------------------------
# Sub-models
# ---------------------------------------------------------------------------

class CodeSnippet(BaseModel):
    """A single Python code snippet submitted for review."""
    file_name: str = Field(..., description="Logical file name, e.g. 'auth.py'")
    source: str = Field(..., description="Full Python source code")
    language: str = Field(default="python", description="Always 'python' in this env")


class ReviewComment(BaseModel):
    """A single comment produced by the agent during review."""
    line: Optional[int] = Field(None, ge=1, description="1-indexed line number (None = file-level)")
    category: ReviewCategory
    severity: Severity
    message: str = Field(..., min_length=5, max_length=500)
    suggestion: Optional[str] = Field(None, max_length=500, description="Optional fix suggestion")

    @field_validator("message")
    @classmethod
    def message_not_empty(cls, v: str) -> str:
        if not v.strip():
            raise ValueError("message must not be blank")
        return v.strip()


class TaskSpec(BaseModel):
    """Metadata for a single task within the environment."""
    task_id: str
    title: str
    difficulty: TaskDifficulty
    categories: List[ReviewCategory]
    description: str
    max_steps: int = Field(default=10, ge=1)
    passing_threshold: float = Field(default=0.6, ge=0.0, le=1.0)


# ---------------------------------------------------------------------------
# Core OpenEnv models
# ---------------------------------------------------------------------------

class Observation(BaseModel):
    """What the agent sees at each step."""
    task_id: str
    step: int = Field(..., ge=0)
    snippet: CodeSnippet
    instructions: str
    previous_comments: List[ReviewComment] = Field(default_factory=list)
    feedback: Optional[str] = Field(None, description="Env feedback on last action")
    done: bool = False


class Action(BaseModel):
    """What the agent submits at each step."""
    comments: List[ReviewComment] = Field(
        ...,
        min_length=0,
        description="All review comments produced this step"
    )
    summary: Optional[str] = Field(
        None,
        max_length=1000,
        description="Optional overall review summary (required for hard task)"
    )
    submit: bool = Field(
        default=False,
        description="Set True to finalise the review and trigger grader"
    )

    @field_validator("comments")
    @classmethod
    def no_duplicate_lines(cls, v: List[ReviewComment]) -> List[ReviewComment]:
        seen: set[tuple] = set()
        deduped: List[ReviewComment] = []
        for c in v:
            key = (c.line, c.category, c.message[:40])
            if key not in seen:
                seen.add(key)
                deduped.append(c)
        return deduped


class Reward(BaseModel):
    """Reward signal returned after each step."""
    value: float = Field(..., ge=-1.0, le=1.0)
    breakdown: Dict[str, float] = Field(
        default_factory=dict,
        description="Per-component scores summing to value"
    )
    reason: str = Field(default="", description="Human-readable explanation")


class StepResult(BaseModel):
    """Full return value of env.step()."""
    observation: Observation
    reward: Reward
    done: bool
    info: Dict[str, Any] = Field(default_factory=dict)


class EnvironmentState(BaseModel):
    """Complete serialisable snapshot returned by env.state()."""
    task_id: str
    step: int
    max_steps: int
    total_reward: float
    comments_so_far: List[ReviewComment]
    done: bool
    grader_scores: Dict[str, Any] = Field(default_factory=dict)
