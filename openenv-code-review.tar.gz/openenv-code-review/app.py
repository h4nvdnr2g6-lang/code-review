"""
FastAPI server exposing the CodeReviewEnv over HTTP.

Endpoints
---------
POST /reset          – Start or restart an episode
POST /step           – Submit an action
GET  /state          – Get full environment state
GET  /tasks          – List available tasks
GET  /health         – Health check
GET  /               – Landing page (HTML)
"""

from __future__ import annotations

import os
from typing import Any, Dict

from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import HTMLResponse
from pydantic import BaseModel

from env.environment import TASK_SPECS, CodeReviewEnv
from env.models import Action, StepResult, EnvironmentState, TaskSpec

# ---------------------------------------------------------------------------
# App setup
# ---------------------------------------------------------------------------

app = FastAPI(
    title="CodeReview OpenEnv",
    description="An OpenEnv-compliant Python code review environment for AI agent training.",
    version="1.0.0",
    docs_url="/docs",
    redoc_url="/redoc",
)

# Global session store (single-session; for multi-agent use, key by session_id)
_sessions: Dict[str, CodeReviewEnv] = {}


def _get_env(session_id: str) -> CodeReviewEnv:
    if session_id not in _sessions:
        raise HTTPException(status_code=404, detail=f"No active session '{session_id}'. Call /reset first.")
    return _sessions[session_id]


# ---------------------------------------------------------------------------
# Request / Response models
# ---------------------------------------------------------------------------

class ResetRequest(BaseModel):
    task_id: str = "task_1_easy"
    session_id: str = "default"


class StepRequest(BaseModel):
    action: Action
    session_id: str = "default"


class StateRequest(BaseModel):
    session_id: str = "default"


# ---------------------------------------------------------------------------
# Routes
# ---------------------------------------------------------------------------

@app.get("/", response_class=HTMLResponse)
async def landing():
    tasks_html = ""
    for tid, spec in TASK_SPECS.items():
        tasks_html += f"""
        <div class="task">
          <h3>{spec.title} <span class="badge {spec.difficulty.value}">{spec.difficulty.value.upper()}</span></h3>
          <p>{spec.description}</p>
          <small>Max steps: {spec.max_steps} | Passing threshold: {spec.passing_threshold}</small>
        </div>
        """
    return f"""
    <!DOCTYPE html>
    <html>
    <head>
      <title>CodeReview OpenEnv</title>
      <style>
        body {{ font-family: system-ui, sans-serif; max-width: 860px; margin: 40px auto; padding: 0 20px; background: #0f1117; color: #e2e8f0; }}
        h1 {{ color: #7dd3fc; }} h2 {{ color: #94a3b8; border-bottom: 1px solid #334155; padding-bottom: 8px; }}
        .task {{ background: #1e293b; border-radius: 8px; padding: 16px; margin: 12px 0; }}
        .badge {{ font-size: 11px; padding: 2px 8px; border-radius: 12px; font-weight: bold; }}
        .easy {{ background: #166534; color: #86efac; }}
        .medium {{ background: #92400e; color: #fcd34d; }}
        .hard {{ background: #7f1d1d; color: #fca5a5; }}
        a {{ color: #7dd3fc; }} code {{ background: #0f172a; padding: 2px 6px; border-radius: 4px; font-size: 13px; }}
        pre {{ background: #0f172a; padding: 16px; border-radius: 8px; overflow-x: auto; }}
      </style>
    </head>
    <body>
      <h1>🔍 CodeReview OpenEnv</h1>
      <p>An OpenEnv-compliant AI training environment that simulates Python code review.</p>
      <h2>Available Tasks</h2>
      {tasks_html}
      <h2>Quick Start</h2>
      <pre>
# 1. Reset and start a session
curl -X POST /reset -H 'Content-Type: application/json' \\
     -d '{{"task_id": "task_1_easy", "session_id": "my-agent"}}'

# 2. Step with an action
curl -X POST /step -H 'Content-Type: application/json' \\
     -d '{{"session_id": "my-agent", "action": {{ "comments": [...], "submit": true }}}}'

# 3. Check state
curl /state?session_id=my-agent
      </pre>
      <p><a href="/docs">📖 Interactive API Docs (Swagger)</a> | <a href="/redoc">ReDoc</a></p>
    </body>
    </html>
    """


@app.get("/health")
async def health() -> dict:
    return {"status": "ok", "version": "1.0.0"}


@app.get("/tasks")
async def list_tasks() -> Dict[str, Any]:
    return {
        tid: {
            "title": spec.title,
            "difficulty": spec.difficulty.value,
            "categories": spec.categories,
            "description": spec.description,
            "max_steps": spec.max_steps,
            "passing_threshold": spec.passing_threshold,
        }
        for tid, spec in TASK_SPECS.items()
    }


@app.post("/reset")
async def reset(req: ResetRequest) -> dict:
    env = CodeReviewEnv(task_id=req.task_id)
    _sessions[req.session_id] = env
    obs = env.reset()
    return {
        "session_id": req.session_id,
        "task_id": req.task_id,
        "observation": obs.model_dump(),
    }


@app.post("/step")
async def step(req: StepRequest) -> dict:
    env = _get_env(req.session_id)
    try:
        result: StepResult = env.step(req.action)
    except RuntimeError as e:
        raise HTTPException(status_code=400, detail=str(e))
    return result.model_dump()


@app.get("/state")
async def state(session_id: str = "default") -> dict:
    env = _get_env(session_id)
    return env.state().model_dump()
